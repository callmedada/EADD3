<?php

namespace Conduit\Models;

use Illuminate\Database\Eloquent\Model;


/**

 */
class Location extends Model
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'location_latitude',
        'location_longitude',
        'vehicle_id',
    ];

    /********************
     *  Relationships
     ********************/

    public function status()
    {
        return $this->belongsTo(Article::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}