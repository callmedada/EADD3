<?php

namespace Conduit\Controllers\Location;

use Conduit\Models\Article;
use Conduit\Models\Location;
use Conduit\Transformers\ArticleTransformer;
use Conduit\Transformers\LocationTransformer;
use Interop\Container\ContainerInterface;
use League\Fractal\Resource\Collection;
use League\Fractal\Resource\Item;
use Slim\Http\Request;
use Slim\Http\Response;
use Respect\Validation\Validator as v;

class LocationController
{

    /** @var \Conduit\Validation\Validator */
    protected $validator;
    /** @var \Illuminate\Database\Capsule\Manager */
    protected $db;
    /** @var \Conduit\Services\Auth\Auth */
    protected $auth;
    /** @var \League\Fractal\Manager */
    protected $fractal;

    /**
     * UserController constructor.
     *
     * @param \Interop\Container\ContainerInterface $container
     *
     * @internal param $auth
     */
    public function __construct(ContainerInterface $container)
    {
        // $this->auth = $container->get('auth');
        $this->fractal = $container->get('fractal');
        // $this->validator = $container->get('validator');
        $this->db = $container->get('db');
    }

    /**
     * Return a all Comment for an article
     *
     * @param \Slim\Http\Request  $request
     * @param \Slim\Http\Response $response
     * @param array               $args
     *
     * @return \Slim\Http\Response
     */
    public function index(Request $request, Response $response, array $args)
    {
        $builder = Location::query()->latest()->limit(20);

        $data = $this->fractal->createData(new Collection($builder->get(),
            new LocationTransformer()))->toArray();

        return $response->withJson(['locations' => $data['data']]);
    }

    /**
     * Create a new location
     *
     * @param \Slim\Http\Request  $request
     * @param \Slim\Http\Response $response
     *
     * @param array               $args
     *
     * @return \Slim\Http\Response
     */
    public function store(Request $request, Response $response, array $args)
    {
        $data = $request->getParam('location')[0];
        $shuttle = Location::query()->where('vehicle_id', $data['vehicle_id'])->firstOrFail();

        $shuttle->update([
            'location_latitude'       => $data['location_latitude'],
            'location_longitude' => $data['location_longitude'],
        ]);


        $data = $this->fractal->createData(new Item($shuttle, new LocationTransformer()))->toArray();

        return $response->withJson(['location' => $data]);

    }

    /**
     * Delete A Comment Endpoint
     *
     * @param \Slim\Http\Request  $request
     * @param \Slim\Http\Response $response
     * @param array               $args
     *
     * @return \Slim\Http\Response
     */
    public function destroy(Request $request, Response $response, array $args)
    {
        $comment = Comment::query()->findOrFail($args['id']);
        $requestUser = $this->auth->requestUser($request);

        if (is_null($requestUser)) {
            return $response->withJson([], 401);
        }

        if ($requestUser->id != $comment->user_id) {
            return $response->withJson(['message' => 'Forbidden'], 403);
        }

        $comment->delete();

        return $response->withJson([], 200);
    }

}