<?php

namespace Conduit\Transformers;

use Conduit\Models\Article;
use League\Fractal\TransformerAbstract;

class ArticleTransformer extends TransformerAbstract
{

    /**
     * Include resources without needing it to be requested.
     *
     * @var array
     */
    protected $defaultIncludes = [
        'author',
    ];

    /**
     * @var integer|null
     */
    protected $requestUserId;

    /**
     * ArticleTransformer constructor.
     *
     * @param int $requestUserId
     */
    public function __construct($requestUserId = null)
    {
        $this->requestUserId = $requestUserId;
    }

    public function transform(Article $buscheckin)
    {
        return [
            "id"           => $buscheckin->id,
            "name"          => $buscheckin->name,
            "dept"           => $buscheckin->dept,
            "branch"          => $buscheckin->branch,
            'guest'       => $buscheckin->guest,
        ];
    }


    /**
     * Include Author
     *
     * @param \Conduit\Models\Article $article
     *
     * @return \League\Fractal\Resource\Item
     * @internal param \Conduit\Models\Comment $comment
     *
     */
    public function includeAuthor(Article $article)
    {
        // $author = $article->user;

        // return $this->item($author, new AuthorTransformer($this->requestUserId));
    }

}