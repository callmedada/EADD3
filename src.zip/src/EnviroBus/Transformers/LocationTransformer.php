<?php

namespace Conduit\Transformers;

use Conduit\Models\Article;
use Conduit\Models\Location;
use Conduit\Models\User;
use League\Fractal\ItemResource;
use League\Fractal\TransformerAbstract;

class LocationTransformer extends TransformerAbstract
{

    /**
     * Include resources without needing it to be requested.
     *
     * @var array
     */
    protected $defaultIncludes = [
    ];

    /**
     * @var integer|null
     */
    protected $requestUserId;

    /**
     * CommentTransformer constructor.
     *
     * @param int $requestUserId
     */
    public function __construct($requestUserId = null)
    {
    }

    public function transform(Location $location)
    {
        var_dump($location->update_at);
        return [
            'vehicle_id'        => $location->vehicle_id,
            'createdAt' => $location->created_at->toIso8601String(),
            'updatedAt' => $location->updated_at->toIso8601String(),
            "location_longitude" =>(float)$location->location_longitude,
            "location_latitude" =>(float)$location->location_latitude,
        ];
    }

    /**
     * Include Author
     *
     * @param \Conduit\Models\Comment $comment
     *
     * @return \League\Fractal\Resource\Item
     */
    public function includeAuthor(Comment $comment)
    {
        $author = $comment->user;

        return $this->item($author, new AuthorTransformer($this->requestUserId));
    }
}