<?php

use Conduit\Controllers\Article\ArticleController;
use Conduit\Controllers\Article\CommentController;
use Conduit\Controllers\Article\FavoriteController;
use Conduit\Controllers\Auth\LoginController;
use Conduit\Controllers\Location\LocationController;
use Conduit\Controllers\Auth\RegisterController;
use Conduit\Controllers\User\ProfileController;
use Conduit\Controllers\User\UserController;
use Conduit\Middleware\OptionalAuth;
use Conduit\Models\Tag;
use Slim\Http\Request;
use Slim\Http\Response;


// Api Routes
$app->group('/api',
    function () {
        $jwtMiddleware = $this->getContainer()->get('jwt');
        $optionalAuth = $this->getContainer()->get('optionalAuth');
        /** @var \Slim\App $this */

        // Auth Routes
        $this->post('/users', RegisterController::class . ':register')->setName('auth.register');
        $this->post('/users/login', LoginController::class . ':login')->setName('auth.login');

        // User Routes
        $this->get('/user', UserController::class . ':show')->add($jwtMiddleware)->setName('user.show');
        $this->put('/user', UserController::class . ':update')->add($jwtMiddleware)->setName('user.update');


        // checkin Routes
        $this->get('/checkin/feed', ArticleController::class . ':index')->add($optionalAuth)->setName('article.index');
        $this->get('/checkin/{slug}', ArticleController::class . ':show')->add($jwtMiddleware)->setName('article.show');
        $this->put('/checkin/{slug}',
            ArticleController::class . ':update')->add($jwtMiddleware)->setName('article.update');
        $this->delete('/checkin/{slug}',
            ArticleController::class . ':destroy')->add($jwtMiddleware)->setName('article.destroy');
        $this->post('/checkins', ArticleController::class . ':store')->add($jwtMiddleware)->setName('article.store');
        $this->get('/checkins', ArticleController::class . ':index')->add($optionalAuth)->setName('article.index');

        // location Routes
        $this->post('/location/{shuttlename}', LocationController::class . ':store')
            ->setName('location.store');
        $this->get('/location', LocationController::class . ':index')
            ->setName('location.index');

        // Tags Route
        $this->get('/tags', function (Request $request, Response $response) {
            return $response->withJson([
                'tags' => Tag::all('title')->pluck('title'),
            ]);
        });


    });


// Routes

$app->get('/[{name}]',
    function (Request $request, Response $response, array $args) {
        // Sample log message
        $this->logger->info("Slim-Skeleton '/' route");

        // Render index view
        return $this->renderer->render($response, 'index.phtml', $args);
    });

$app->get('/key/gettoken',function ($request, $response, $args) {
        $nameKey = $this->csrf->getTokenNameKey();
        $valueKey = $this->csrf->getTokenValueKey();
        $name = $request->getAttribute($nameKey);
        $value = $request->getAttribute($valueKey);
    
        $tokenArray = [
            $nameKey => $name,
            $valueKey => $value
        ];
        
        return $response->write(json_encode($tokenArray));
    })->add($container->get('csrf'));